<template>
  <div class="card mb-4">
    <div class="card-header bg-info text-white">Attendance Tracking</div>

    <div class="card-body">
      <table class="table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Status</th>
          </tr>
        </thead>

        <tbody>
          <tr v-for="employee in employees" :key="employee.id">
            <td>{{ employee.name }}</td>

            <td>
              <span
                :class="
                  employee.attendance === 'Present'
                    ? 'badge bg-success'
                    : 'badge bg-danger'
                "
              >
                {{ employee.attendance }}
              </span>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
export default {
  props: ["employees"],
};
</script>
