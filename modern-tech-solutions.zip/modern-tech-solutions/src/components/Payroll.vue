<template>
  <div class="card mb-4">
    <div class="card-header bg-success text-white">Payroll Processing</div>

    <div class="card-body">
      <select class="form-select mb-3" v-model="selectedEmployee">
        <option disabled value="">Select Employee</option>

        <option v-for="emp in employees" :key="emp.id" :value="emp">
          {{ emp.name }}
        </option>
      </select>

      <div v-if="selectedEmployee">
        <h5>Digital Payslip</h5>

        <p><strong>Name:</strong> {{ selectedEmployee.name }}</p>

        <p>
          <strong>Basic Salary:</strong>
          R{{ selectedEmployee.salary }}
        </p>

        <p>
          <strong>Tax (15%):</strong>
          R{{ tax }}
        </p>

        <p>
          <strong>Net Salary:</strong>
          R{{ netSalary }}
        </p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: ["employees"],

  data() {
    return {
      selectedEmployee: "",
    };
  },

  computed: {
    tax() {
      return (this.selectedEmployee.salary * 0.15).toFixed(2);
    },

    netSalary() {
      return (this.selectedEmployee.salary * 0.85).toFixed(2);
    },
  },
};
</script>
