<template>
  <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
      <a class="navbar-brand fw-bold"> ModernTech HR System </a>
    </div>
  </nav>
</template>
