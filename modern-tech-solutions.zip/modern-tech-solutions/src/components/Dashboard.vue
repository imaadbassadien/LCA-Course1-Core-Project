<template>
  <div class="row mb-4">
    <div class="col-md-4">
      <div class="card text-center shadow">
        <div class="card-body">
          <h5>Total Employees</h5>
          <h2>{{ employees.length }}</h2>
        </div>
      </div>
    </div>

    <div class="col-md-4">
      <div class="card text-center shadow">
        <div class="card-body">
          <h5>Present Today</h5>
          <h2>{{ presentCount }}</h2>
        </div>
      </div>
    </div>

    <div class="col-md-4">
      <div class="card text-center shadow">
        <div class="card-body">
          <h5>On Leave/Absent</h5>
          <h2>{{ absentCount }}</h2>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: ["employees"],
  computed: {
    presentCount() {
      return this.employees.filter((e) => e.attendance === "Present").length;
    },
    absentCount() {
      return this.employees.filter((e) => e.attendance === "Absent").length;
    },
  },
};
</script>
