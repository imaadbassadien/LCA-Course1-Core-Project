<template>
  <div class="card mb-4">
    <div class="card-header bg-warning">Leave Requests</div>

    <div class="card-body">
      <table class="table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Leave Balance</th>
            <th>Status</th>
          </tr>
        </thead>

        <tbody>
          <tr v-for="employee in employees" :key="employee.id">
            <td>{{ employee.name }}</td>
            <td>{{ employee.leaveBalance }}</td>
            <td>
              <span class="badge bg-success"> Approved </span>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
export default {
  props: ["employees"],
};
</script>
