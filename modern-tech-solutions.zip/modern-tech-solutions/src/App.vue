<template>
  <div>
    <Navbar />

    <div class="container mt-4">
      <Dashboard :employees="employees" />

      <EmployeeTable :employees="employees" />

      <Payroll :employees="employees" />

      <LeaveRequests :employees="employees" />

      <Attendance :employees="employees" />
    </div>
  </div>
</template>

<script>
import employees from "./data/employees";
import Navbar from "./components/Navbar.vue";
import Dashboard from "./components/Dashboard.vue";
import EmployeeTable from "./components/EmployeeTable.vue";
import Payroll from "./components/Payroll.vue";
import LeaveRequests from "./components/LeaveRequests.vue";
import Attendance from "./components/Attendance.vue";

export default {
  components: {
    Navbar,
    Dashboard,
    EmployeeTable,
    Payroll,
    LeaveRequests,
    Attendance,
  },
  data() {
    return {
      employees,
    };
  },
};
</script>
