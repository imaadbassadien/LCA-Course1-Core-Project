export default [
  {
    id: 1,
    name: "John Smith",
    department: "Development",
    position: "Frontend Developer",
    salary: 42000,
    leaveBalance: 18,
    attendance: "Present"
  },
  {
    id: 2,
    name: "Sarah Johnson",
    department: "HR",
    position: "HR Manager",
    salary: 48000,
    leaveBalance: 15,
    attendance: "Present"
  },
  {
    id: 3,
    name: "Michael Brown",
    department: "Development",
    position: "Backend Developer",
    salary: 45000,
    leaveBalance: 12,
    attendance: "Absent"
  },
  {
    id: 4,
    name: "Emma Wilson",
    department: "Finance",
    position: "Accountant",
    salary: 39000,
    leaveBalance: 20,
    attendance: "Present"
  },
  {
    id: 5,
    name: "David Lee",
    department: "Support",
    position: "Support Engineer",
    salary: 32000,
    leaveBalance: 14,
    attendance: "Present"
  },
  {
    id: 6,
    name: "Sophia Davis",
    department: "Marketing",
    position: "Marketing Specialist",
    salary: 36000,
    leaveBalance: 16,
    attendance: "Present"
  },
  {
    id: 7,
    name: "James Miller",
    department: "Development",
    position: "Full Stack Developer",
    salary: 50000,
    leaveBalance: 10,
    attendance: "Absent"
  },
  {
    id: 8,
    name: "Olivia Taylor",
    department: "Sales",
    position: "Sales Executive",
    salary: 34000,
    leaveBalance: 13,
    attendance: "Present"
  },
  {
    id: 9,
    name: "Daniel Anderson",
    department: "Development",
    position: "QA Tester",
    salary: 31000,
    leaveBalance: 11,
    attendance: "Present"
  },
  {
    id: 10,
    name: "Ava Thomas",
    department: "HR",
    position: "HR Assistant",
    salary: 30000,
    leaveBalance: 17,
    attendance: "Present"
  },
  {
    id: 11,
    name: "Ethan White",
    department: "Finance",
    position: "Financial Analyst",
    salary: 43000,
    leaveBalance: 15,
    attendance: "Present"
  },
  {
    id: 12,
    name: "Mia Harris",
    department: "Marketing",
    position: "Content Creator",
    salary: 33000,
    leaveBalance: 12,
    attendance: "Absent"
  },
  {
    id: 13,
    name: "Lucas Martin",
    department: "Support",
    position: "Helpdesk Technician",
    salary: 29000,
    leaveBalance: 9,
    attendance: "Present"
  },
  {
    id: 14,
    name: "Charlotte Moore",
    department: "Sales",
    position: "Account Manager",
    salary: 41000,
    leaveBalance: 18,
    attendance: "Present"
  },
  {
    id: 15,
    name: "Benjamin Clark",
    department: "Development",
    position: "Software Architect",
    salary: 65000,
    leaveBalance: 22,
    attendance: "Present"
  }
];